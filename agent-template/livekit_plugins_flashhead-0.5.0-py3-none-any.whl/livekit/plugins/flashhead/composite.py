"""Full-frame compositing for the FlashHead avatar.

The engine only ever emits a 512x512 animated face. To publish the whole
reference portrait instead of that square crop, we:

  1. detect the face ourselves and cut the crop the engine would have cut,
  2. hand the engine that crop with ``use_face_crop=False`` so it animates
     exactly the region we chose,
  3. paste each returned frame back into the full still at the same box.

Owning the crop is the point. The engine derives its own bbox internally
(``flash_head/utils/facecrop.py``, ``face_ratio=2.0``) and never reports it --
the ready reply is a bare ``{"type": "ready"}``. Re-deriving it here with a
different detector would land a few percent off and the animated face would
sit visibly out of register with the body. By supplying the crop we make the
paste-back exact by construction.

Detection uses OpenCV's bundled YuNet (``cv2.FaceDetectorYN``). The agent
image ships cv2 5.x, which no longer carries the Haar cascades and has no
``CascadeClassifier``, so the small ONNX is shipped as package data.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import numpy as np

from .log import logger

# Mirrors flash_head/utils/facecrop.py: the detected face box is grown about
# its centre by this factor, so the face ends up occupying ~1/ratio of the
# crop. Keep in step with the engine's default.
DEFAULT_FACE_RATIO = 2.0

# Wire format of the engine's video frames.
CROP_SIZE = 512

# Cap the published frame so a large still does not cost bandwidth for detail
# nobody can see at 25 fps. Aspect ratio is preserved.
DEFAULT_MAX_DIM = 1280

# Body-motion loop. FlashHead animates only the face, so without this the
# torso is a freeze-frame and the result reads as a photo with a moving mouth.
# A short periodic affine (breathe / sway / tilt) applied to the whole
# composited frame restores the sense of a living body, costs one warp per
# frame, and loops seamlessly because every term is a whole number of cycles.
#
# It is deliberately NOT a gesture system: hands and cloth do not articulate.
# Swapping in a pre-rendered body loop (e.g. Wan 2.2 I2V) later replaces only
# the frame source; the compositing path below is unchanged.
DEFAULT_LOOP_SECONDS = 6.0
DEFAULT_BREATHE = 0.006   # scale amplitude, fraction
DEFAULT_SWAY_PX = 5.0     # horizontal drift, pixels
DEFAULT_TILT_DEG = 0.35   # rotation amplitude, degrees

_MODEL_ENV = "FLASHHEAD_FACE_MODEL"
_MODEL_NAME = "face_detection_yunet_2023mar.onnx"


class CompositeUnavailable(RuntimeError):
    """Compositing cannot run — caller should fall back to head-only."""


def _model_path() -> str:
    override = os.getenv(_MODEL_ENV)
    if override:
        return override
    return os.path.join(os.path.dirname(__file__), "models", _MODEL_NAME)


def _even(n: int) -> int:
    """Video encoders dislike odd dimensions."""
    return n - (n % 2)


@dataclass(frozen=True)
class CropBox:
    x1: int
    y1: int
    x2: int
    y2: int

    @property
    def width(self) -> int:
        return self.x2 - self.x1

    @property
    def height(self) -> int:
        return self.y2 - self.y1


class MotionLoop:
    """Periodic affine applied to the whole composited frame.

    Anchored low in the frame so the torso carries most of the movement and
    the head — where the animated face is pasted — stays comparatively still.
    Because the face is composited *before* this warp, it travels with the
    body automatically and no per-frame face tracking is needed.
    """

    def __init__(
        self,
        size: tuple[int, int],
        *,
        fps: int = 25,
        seconds: float = DEFAULT_LOOP_SECONDS,
        breathe: float = DEFAULT_BREATHE,
        sway_px: float = DEFAULT_SWAY_PX,
        tilt_deg: float = DEFAULT_TILT_DEG,
    ) -> None:
        import cv2

        w, h = size
        self.period = max(1, int(round(fps * seconds)))
        # Anchor near the base of the frame: scaling about the chest keeps the
        # crown from bobbing, which is what makes cheap warps look wobbly.
        cx, cy = w / 2.0, h * 0.85
        self._mats = []
        for i in range(self.period):
            t = 2.0 * np.pi * (i / self.period)
            scale = 1.0 + breathe * np.sin(t)
            angle = tilt_deg * np.sin(t)
            m = cv2.getRotationMatrix2D((cx, cy), angle, scale)
            m[0, 2] += sway_px * np.sin(t)
            # Vertical term runs at double rate so the loop reads as a breath
            # rather than a sway, and still closes cleanly.
            m[1, 2] += (sway_px * 0.4) * np.sin(2.0 * t)
            self._mats.append(m.astype(np.float32))

    def apply(self, frame: np.ndarray, idx: int) -> np.ndarray:
        import cv2

        h, w = frame.shape[:2]
        return cv2.warpAffine(
            frame, self._mats[idx % self.period], (w, h),
            flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE,
        )


class FaceCompositor:
    """Holds the still, the crop handed to the engine, and the paste-back."""

    def __init__(
        self,
        image_bytes: bytes,
        *,
        face_ratio: float = DEFAULT_FACE_RATIO,
        max_dim: int = DEFAULT_MAX_DIM,
        feather: float = 0.08,
        motion: bool = False,
        motion_seconds: float = DEFAULT_LOOP_SECONDS,
        fps: int = 25,
    ) -> None:
        try:
            import cv2  # noqa: F401
        except Exception as e:  # pragma: no cover - depends on image contents
            raise CompositeUnavailable(f"opencv not available: {e}") from e
        import cv2

        buf = np.frombuffer(image_bytes, dtype=np.uint8)
        bgr = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        if bgr is None:
            raise CompositeUnavailable("reference image could not be decoded")

        bgr = self._downscale(bgr, max_dim)
        h, w = bgr.shape[:2]

        self._box = self._detect(bgr, face_ratio)
        logger.info(
            "flashhead: compositing enabled — still=%dx%d face_box=(%d,%d,%d,%d)",
            w, h, self._box.x1, self._box.y1, self._box.x2, self._box.y2,
        )

        crop = bgr[self._box.y1:self._box.y2, self._box.x1:self._box.x2]
        crop512 = cv2.resize(crop, (CROP_SIZE, CROP_SIZE), interpolation=cv2.INTER_AREA)
        ok, png = cv2.imencode(".png", crop512)
        if not ok:
            raise CompositeUnavailable("failed to encode face crop")
        self._crop_png = png.tobytes()

        # Frames arrive RGB24; keep the canvas in the same order so the paste
        # is a plain slice assignment.
        self._base = np.ascontiguousarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
        self._alpha = self._feather_mask(self._box, feather)

        self._frame_idx = 0
        self._motion = (
            MotionLoop((w, h), fps=fps, seconds=motion_seconds) if motion else None
        )
        if self._motion is not None:
            logger.info(
                "flashhead: body motion loop on — %.1fs / %d frames",
                motion_seconds, self._motion.period,
            )

    # -- construction helpers ------------------------------------------

    @staticmethod
    def _downscale(bgr: np.ndarray, max_dim: int) -> np.ndarray:
        import cv2

        h, w = bgr.shape[:2]
        scale = min(1.0, float(max_dim) / float(max(w, h)))
        nw, nh = _even(int(round(w * scale))), _even(int(round(h * scale)))
        if (nw, nh) == (w, h):
            return bgr
        return cv2.resize(bgr, (nw, nh), interpolation=cv2.INTER_AREA)

    @staticmethod
    def _detect(bgr: np.ndarray, face_ratio: float) -> CropBox:
        import cv2

        model = _model_path()
        if not os.path.isfile(model):
            raise CompositeUnavailable(f"face model missing: {model}")

        h, w = bgr.shape[:2]
        det = cv2.FaceDetectorYN.create(model, "", (w, h), 0.6, 0.3, 5000)
        det.setInputSize((w, h))
        _, faces = det.detect(bgr)
        if faces is None or len(faces) == 0:
            raise CompositeUnavailable("no face detected in reference image")

        # Largest face — portraits occasionally catch a background face.
        x, y, fw, fh = sorted(faces, key=lambda f: f[2] * f[3], reverse=True)[0][:4]
        cx, cy = x + fw / 2.0, y + fh / 2.0
        side = max(fw, fh) * face_ratio

        # Keep the box square and inside the frame: shrink the side rather
        # than clip one edge, or the paste-back would be non-uniformly scaled.
        side = min(side, float(w), float(h))
        half = side / 2.0
        cx = min(max(cx, half), w - half)
        cy = min(max(cy, half), h - half)

        x1, y1 = int(round(cx - half)), int(round(cy - half))
        s = _even(int(round(side)))
        return CropBox(x1, y1, x1 + s, y1 + s)

    @staticmethod
    def _feather_mask(box: CropBox, feather: float) -> np.ndarray:
        """Soft-edged alpha so the pasted face does not show a hard seam."""
        h, w = box.height, box.width
        edge = max(1, int(round(min(h, w) * feather)))
        ramp = np.linspace(0.0, 1.0, edge, dtype=np.float32)

        col = np.ones(w, dtype=np.float32)
        col[:edge] = ramp
        col[-edge:] = ramp[::-1]
        row = np.ones(h, dtype=np.float32)
        row[:edge] = ramp
        row[-edge:] = ramp[::-1]

        return (row[:, None] * col[None, :])[:, :, None]

    # -- public API ----------------------------------------------------

    @property
    def crop_png(self) -> bytes:
        """PNG of the 512x512 face crop to hand the engine."""
        return self._crop_png

    @property
    def frame_size(self) -> tuple[int, int]:
        """(width, height) of the composited frames we publish."""
        h, w = self._base.shape[:2]
        return w, h

    def composite(self, frame_rgb: bytes) -> bytes:
        """Paste one 512x512 RGB24 engine frame into the still."""
        import cv2

        face = np.frombuffer(frame_rgb, dtype=np.uint8)
        if face.size != CROP_SIZE * CROP_SIZE * 3:
            raise ValueError(f"unexpected frame size {face.size}")
        face = face.reshape(CROP_SIZE, CROP_SIZE, 3)

        b = self._box
        resized = cv2.resize(face, (b.width, b.height), interpolation=cv2.INTER_LINEAR)

        out = self._base.copy()
        region = out[b.y1:b.y2, b.x1:b.x2].astype(np.float32)
        blended = resized.astype(np.float32) * self._alpha + region * (1.0 - self._alpha)
        out[b.y1:b.y2, b.x1:b.x2] = blended.astype(np.uint8)

        # Warp after compositing so the face rides along with the body.
        if self._motion is not None:
            out = self._motion.apply(out, self._frame_idx)
            self._frame_idx += 1

        return np.ascontiguousarray(out).tobytes()
