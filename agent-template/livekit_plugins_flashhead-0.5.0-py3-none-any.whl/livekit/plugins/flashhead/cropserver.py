"""Serve the face crop to flashhead-engine over the cluster network.

The engine resolves ``reference_image`` as either an http(s) URL or a local
path (``_resolve_reference_image``); it has no data-URL or upload path, and it
runs in a different pod, so a file we write locally is invisible to it.

Rather than add object storage or a platform endpoint just to move ~200 KB
once per session, the plugin serves the crop itself on an ephemeral port for
the few seconds the engine needs to fetch it. The engine downloads the
reference once during ``init``, so the server is torn down as soon as the
session is ready.
"""

from __future__ import annotations

import asyncio
import socket
from urllib.parse import urlparse

from aiohttp import web

from .log import logger

_PATH = "/ref.png"


def _local_ip_towards(target_url: str) -> str:
    """The address of ours the engine will actually be able to reach.

    A pod can have several interfaces, and POD_IP is only present if the
    deployment wires up the downward API. Opening a UDP socket toward the
    engine costs no packets and makes the kernel pick the source address it
    would really use for that route.
    """
    host = urlparse(target_url).hostname or "8.8.8.8"
    port = urlparse(target_url).port or 80
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect((host, port))
        return s.getsockname()[0]
    except Exception:
        return socket.gethostbyname(socket.gethostname())
    finally:
        s.close()


class CropServer:
    """One-shot HTTP server exposing a single PNG."""

    def __init__(self, png: bytes, *, engine_url: str) -> None:
        self._png = png
        self._engine_url = engine_url
        self._runner: web.AppRunner | None = None
        self._url: str | None = None
        self._served = asyncio.Event()

    @property
    def url(self) -> str:
        if not self._url:
            raise RuntimeError("CropServer.start() has not run")
        return self._url

    @property
    def fetched(self) -> asyncio.Event:
        """Set once the engine has pulled the crop."""
        return self._served

    async def _handle(self, _request: web.Request) -> web.Response:
        self._served.set()
        return web.Response(body=self._png, content_type="image/png")

    async def start(self) -> str:
        app = web.Application()
        app.router.add_get(_PATH, self._handle)
        self._runner = web.AppRunner(app, access_log=None)
        await self._runner.setup()

        ip = _local_ip_towards(self._engine_url)
        site = web.TCPSite(self._runner, "0.0.0.0", 0)
        await site.start()

        port = None
        for sock in site._server.sockets:  # type: ignore[union-attr]
            port = sock.getsockname()[1]
            break
        if port is None:
            raise RuntimeError("could not determine crop server port")

        self._url = f"http://{ip}:{port}{_PATH}"
        logger.info("flashhead: serving face crop at %s", self._url)
        return self._url

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None
