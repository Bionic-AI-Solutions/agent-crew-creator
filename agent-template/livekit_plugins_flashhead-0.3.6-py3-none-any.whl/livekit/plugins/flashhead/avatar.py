"""SoulX-FlashHead avatar plugin — WebSocket client for the flashhead-engine.

This is a thin client: it talks to a separate GPU-backed engine service
(``flashhead-engine``) over WebSocket and publishes the received video +
audio frames to the LiveKit room via LiveKit's ``AvatarRunner``. The
client itself has no CUDA, torch, or FlashHead dependency — drop-in
usable from any LiveKit agent.

Architecture:

    your agent  ──(TTS audio)──▶  livekit.plugins.flashhead.AvatarSession
                                         │ WebSocket
                                         ▼
                          flashhead-engine (GPU Deployment)
                          runs the FlashHead pipeline,
                          emits video + synced audio frames
                                         │
                                         ▼
                           AvatarRunner publishes them
                             to the LiveKit room

Usage:

    from livekit.agents import AgentSession, JobContext
    from livekit.plugins import flashhead

    async def entrypoint(ctx: JobContext):
        session = AgentSession(...)

        avatar = flashhead.AvatarSession(
            api_url="ws://flashhead-engine.livekit-agents:8080/v1/session",
            reference_image="https://cdn.example.com/faces/alice.jpg",
        )
        await avatar.start(session, ctx.room)
        await session.start(agent=..., room=ctx.room)
"""
from __future__ import annotations

import asyncio
import os
from collections.abc import AsyncGenerator, AsyncIterator

import aiohttp
import numpy as np

from livekit import rtc
from livekit.agents import (
    AgentSession,
    NOT_GIVEN,
    NotGivenOr,
    utils,
)
from livekit.agents.voice.avatar import (
    AudioSegmentEnd,
    AvatarOptions,
    AvatarRunner,
    AvatarSession as BaseAvatarSession,
    QueueAudioOutput,
    VideoGenerator,
)

from .log import logger

# Protocol constants — duplicated from flashhead-engine's protocol.py so
# the plugin stays independent of the engine package. Keep in sync.
_FRAME_VIDEO = 0
_FRAME_AUDIO = 1
_FRAME_SEGMENT_END = 2
_FRAME_ERROR = 0xFF

_WIRE_SAMPLE_RATE = 16000
_WIRE_VIDEO_WIDTH = 512
_WIRE_VIDEO_HEIGHT = 512
_WIRE_VIDEO_FPS = 25

_AVATAR_AGENT_IDENTITY = "flashhead-avatar-agent"
_AVATAR_AGENT_NAME = "flashhead-avatar-agent"


class FlashHeadException(Exception):
    """Errors from the flashhead plugin or engine."""


class AvatarSession(BaseAvatarSession):
    """FlashHead avatar session backed by a remote flashhead-engine."""

    def __init__(
        self,
        *,
        api_url: NotGivenOr[str] = NOT_GIVEN,
        reference_image: NotGivenOr[str] = NOT_GIVEN,
        # Default to cropping to the face region in the reference image.
        # FlashHead's motion model only animates a detected face; passing a
        # full-scene portrait (GenImage career portraits, arbitrary user
        # uploads) without face-cropping produces stretched/smeared lips.
        # Override to False only if the reference is already a tight 512x512
        # face crop and you want to keep the edge composition.
        use_face_crop: bool = True,
        seed: int = 42,
        avatar_participant_identity: NotGivenOr[str] = NOT_GIVEN,
        avatar_participant_name: NotGivenOr[str] = NOT_GIVEN,
        connect_timeout: float = 30.0,
        ready_timeout: float = 180.0,
    ) -> None:
        self._api_url = api_url or os.getenv("FLASHHEAD_ENGINE_URL")
        self._reference_image = reference_image or os.getenv(
            "FLASHHEAD_REFERENCE_IMAGE"
        )
        self._use_face_crop = use_face_crop
        self._seed = seed
        self._connect_timeout = connect_timeout
        self._ready_timeout = ready_timeout

        self._avatar_participant_identity = (
            avatar_participant_identity or _AVATAR_AGENT_IDENTITY
        )
        self._avatar_participant_name = avatar_participant_name or _AVATAR_AGENT_NAME

        if not self._api_url:
            raise FlashHeadException(
                "`api_url` or FLASHHEAD_ENGINE_URL env must be set"
            )
        if not self._reference_image:
            raise FlashHeadException(
                "`reference_image` or FLASHHEAD_REFERENCE_IMAGE env must be set"
            )

        self._avatar_runner: AvatarRunner | None = None
        self._generator: FlashHeadGenerator | None = None

    async def start(
        self,
        agent_session: AgentSession,
        room: rtc.Room,
    ) -> None:
        await super().start(agent_session, room)

        self._generator = FlashHeadGenerator(
            api_url=self._api_url,
            reference_image=self._reference_image,
            use_face_crop=self._use_face_crop,
            seed=self._seed,
            connect_timeout=self._connect_timeout,
            ready_timeout=self._ready_timeout,
        )
        await self._generator.connect()

        options = AvatarOptions(
            video_width=_WIRE_VIDEO_WIDTH,
            video_height=_WIRE_VIDEO_HEIGHT,
            video_fps=_WIRE_VIDEO_FPS,
            audio_sample_rate=_WIRE_SAMPLE_RATE,
            audio_channels=1,
        )

        audio_buffer = QueueAudioOutput(sample_rate=_WIRE_SAMPLE_RATE)
        self._avatar_runner = AvatarRunner(
            room=room,
            video_gen=self._generator,
            audio_recv=audio_buffer,
            options=options,
        )
        await self._avatar_runner.start()

        agent_session.output.audio = audio_buffer

    async def aclose(self) -> None:
        if self._generator is not None:
            await self._generator.stop()


class FlashHeadGenerator(VideoGenerator):
    """Bridge between LiveKit's AvatarRunner and the flashhead-engine WS.

    On ``push_audio`` we send int16 PCM bytes to the engine. The engine
    streams back type-prefixed video/audio/segment_end frames which we
    yield directly to the ``AvatarRunner``.
    """

    def __init__(
        self,
        *,
        api_url: str,
        reference_image: str,
        use_face_crop: bool,
        seed: int,
        connect_timeout: float,
        ready_timeout: float,
    ) -> None:
        self._api_url = api_url
        self._reference_image = reference_image
        self._use_face_crop = use_face_crop
        self._seed = seed
        self._connect_timeout = connect_timeout
        self._ready_timeout = ready_timeout

        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._http: aiohttp.ClientSession | None = None
        # Bounded queue to guarantee memory headroom. Engine paces at 25 fps
        # so ~200 slots ≈ 8 seconds of video worst-case; drop-oldest if the
        # AvatarRunner can't drain (usually it can). Each slot holds a
        # rtc.VideoFrame / AudioFrame — not raw bytes — so memory is
        # governed by LiveKit's reference counting.
        self._recv_queue: asyncio.Queue = asyncio.Queue(maxsize=200)
        self._recv_task: asyncio.Task[None] | None = None
        self._closed = False
        self._warned_sr = False

    @property
    def video_resolution(self) -> tuple[int, int]:
        return _WIRE_VIDEO_WIDTH, _WIRE_VIDEO_HEIGHT

    @property
    def video_fps(self) -> int:
        return _WIRE_VIDEO_FPS

    @property
    def audio_sample_rate(self) -> int:
        return _WIRE_SAMPLE_RATE

    async def connect(self) -> None:
        """Open the WS, send init, wait for ``ready``."""
        logger.info(
            "flashhead: connecting to engine %s (reference=%s)",
            self._api_url,
            self._reference_image,
        )
        self._http = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(
                total=None, sock_connect=self._connect_timeout
            )
        )
        try:
            self._ws = await self._http.ws_connect(
                self._api_url,
                heartbeat=30.0,
                max_msg_size=0,  # video frames ~800 KB; remove the default cap
            )
        except Exception as e:
            await self._http.close()
            raise FlashHeadException(f"engine connect failed: {e}") from e

        await self._ws.send_json({
            "type": "init",
            "reference_image": self._reference_image,
            "seed": self._seed,
            "use_face_crop": self._use_face_crop,
        })

        ready = await asyncio.wait_for(
            self._ws.receive_json(), timeout=self._ready_timeout
        )
        if not isinstance(ready, dict):
            raise FlashHeadException(f"engine: unexpected init reply: {ready!r}")
        if ready.get("type") == "error":
            raise FlashHeadException(f"engine init error: {ready.get('message')}")
        if ready.get("type") != "ready":
            raise FlashHeadException(f"engine: unexpected init reply: {ready!r}")

        logger.info("flashhead: engine ready")
        self._recv_task = asyncio.create_task(self._recv_loop())

    async def _recv_loop(self) -> None:
        """Decode binary frames from the engine and push to _recv_queue."""
        assert self._ws is not None
        try:
            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.BINARY:
                    if not msg.data:
                        continue
                    tag = msg.data[0]
                    payload = msg.data[1:]
                    if tag == _FRAME_VIDEO:
                        await self._recv_queue.put(
                            rtc.VideoFrame(
                                width=_WIRE_VIDEO_WIDTH,
                                height=_WIRE_VIDEO_HEIGHT,
                                type=rtc.VideoBufferType.RGB24,
                                data=payload,
                            )
                        )
                    elif tag == _FRAME_AUDIO:
                        samples = len(payload) // 2
                        await self._recv_queue.put(
                            rtc.AudioFrame(
                                data=payload,
                                sample_rate=_WIRE_SAMPLE_RATE,
                                num_channels=1,
                                samples_per_channel=samples,
                            )
                        )
                    elif tag == _FRAME_SEGMENT_END:
                        await self._recv_queue.put(AudioSegmentEnd())
                    elif tag == _FRAME_ERROR:
                        msg_text = payload.decode("utf-8", errors="replace")
                        logger.error("flashhead engine error: %s", msg_text)
                        break
                    else:
                        logger.warning("flashhead: unknown frame tag: %s", tag)
                elif msg.type == aiohttp.WSMsgType.TEXT:
                    # Engine sends text only for control acks; ignore.
                    pass
                elif msg.type in (
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.ERROR,
                ):
                    break
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("flashhead recv loop crashed")
        finally:
            await self._recv_queue.put(None)

    @utils.log_exceptions(logger=logger)
    async def push_audio(self, frame: rtc.AudioFrame | AudioSegmentEnd) -> None:
        if self._ws is None or self._ws.closed:
            return

        if isinstance(frame, AudioSegmentEnd):
            await self._ws.send_json({"type": "segment_end"})
            return

        pcm = np.frombuffer(frame.data, dtype=np.int16).astype(np.float32) / 32768.0
        if frame.num_channels > 1:
            pcm = pcm.reshape(-1, frame.num_channels).mean(axis=1)

        if frame.sample_rate != _WIRE_SAMPLE_RATE:
            if not self._warned_sr:
                logger.warning(
                    "flashhead: engine expects %d Hz but received %d Hz; resampling "
                    "with linear interpolation. Configure your TTS to emit 16 kHz "
                    "for best quality.",
                    _WIRE_SAMPLE_RATE,
                    frame.sample_rate,
                )
                self._warned_sr = True
            ratio = _WIRE_SAMPLE_RATE / frame.sample_rate
            new_len = max(1, int(round(len(pcm) * ratio)))
            pcm = np.interp(
                np.linspace(0, len(pcm) - 1, new_len, dtype=np.float32),
                np.arange(len(pcm), dtype=np.float32),
                pcm,
            ).astype(np.float32)

        pcm_i16 = (pcm * 32767.0).clip(-32768, 32767).astype(np.int16)
        await self._ws.send_bytes(pcm_i16.tobytes())

    def clear_buffer(self) -> None:
        """Barge-in signal from the room — tell the engine to drop its buffer."""
        if self._ws is None or self._ws.closed:
            return
        asyncio.create_task(self._ws.send_json({"type": "clear"}))

    def __aiter__(
        self,
    ) -> AsyncIterator[rtc.VideoFrame | rtc.AudioFrame | AudioSegmentEnd]:
        return self._stream_impl()

    async def _stream_impl(
        self,
    ) -> AsyncGenerator[rtc.VideoFrame | rtc.AudioFrame | AudioSegmentEnd, None]:
        while not self._closed:
            item = await self._recv_queue.get()
            if item is None:
                break
            yield item

    async def stop(self) -> None:
        self._closed = True
        if self._ws is not None and not self._ws.closed:
            try:
                await self._ws.send_json({"type": "close"})
            except Exception:
                pass
            await self._ws.close()
        if self._recv_task is not None:
            self._recv_task.cancel()
            try:
                await self._recv_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._http is not None:
            await self._http.close()
        await self._recv_queue.put(None)
