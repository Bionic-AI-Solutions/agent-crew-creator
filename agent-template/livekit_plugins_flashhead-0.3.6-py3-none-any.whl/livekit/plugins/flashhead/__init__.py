"""SoulX-FlashHead plugin for LiveKit Agents.

Local audio-driven talking-head avatar. See
https://github.com/Soul-AILab/SoulX-FlashHead for the underlying model.
"""

from .avatar import AvatarSession, FlashHeadException, FlashHeadGenerator
from .version import __version__

__all__ = [
    "AvatarSession",
    "FlashHeadException",
    "FlashHeadGenerator",
    "__version__",
]

from livekit.agents import Plugin

from .log import logger


class FlashHeadPlugin(Plugin):
    def __init__(self) -> None:
        super().__init__(__name__, __version__, __package__, logger)


Plugin.register_plugin(FlashHeadPlugin())

_module = dir()
NOT_IN_ALL = [m for m in _module if m not in __all__]

__pdoc__ = {}

for n in NOT_IN_ALL:
    __pdoc__[n] = False
